//tututtuss \u000d
package com.multisoftsystems.database;
import com.multisoftsystems.modal.*;
public class Test  extends ModalTest{

	public static void main(String[] args) {
		Test t=new Test();
		t.disp();

	}

}
