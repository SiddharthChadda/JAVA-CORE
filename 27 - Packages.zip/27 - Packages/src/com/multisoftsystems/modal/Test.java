package com.multisoftsystems.modal;

public class Test {

	public static void main(String[] args) {
		ModalTest m=new ModalTest();

	}

}
