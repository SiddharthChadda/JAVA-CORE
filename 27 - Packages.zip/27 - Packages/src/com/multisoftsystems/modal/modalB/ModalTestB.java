package com.multisoftsystems.modal.modalB;

public class ModalTestB {
	public static int MTB=789;
	protected void disp(){
		System.out.println("inside modal test b");
	}
}
