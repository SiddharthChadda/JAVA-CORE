package com.multisoftsystems.modal.modalA;

public class ModalTestA {

	protected void disp(){
		System.out.println("inside modal test a");
	}
}
