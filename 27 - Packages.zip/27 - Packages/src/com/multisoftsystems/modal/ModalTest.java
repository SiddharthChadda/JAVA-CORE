package com.multisoftsystems.modal;

public  class ModalTest {
	public ModalTest(){}
	protected void disp(){
		System.out.println("inside modal test");
	}
}
