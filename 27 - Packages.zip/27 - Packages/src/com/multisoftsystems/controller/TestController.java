package com.multisoftsystems.controller;
import static com.multisoftsystems.modal.modalB.ModalTestB.MTB;
import static java.lang.System.in;

import java.util.Scanner;
public class TestController  {

	public static void main(String[] args) {
		out.println(MTB);
		out.print("hello");
		Scanner sc=new Scanner(in);
		

	}

}
