package com.example;

public class FinalVariableTest {
	static final int id;
	static{
		id=89;
	}
	public static void main(String[] args) {

	}

}
