package InheritenceType;

public class B extends A {
	int b;
	void b(){
		
		System.out.println("b");
	}
}
