package InheritenceType;

public class A extends Object{
	int a;
	void a(){
		
		System.out.println("a");
	}

}
