package InheritenceType;

public class D extends B,C{

}
