package InheritenceType;

public class C extends A{

}
