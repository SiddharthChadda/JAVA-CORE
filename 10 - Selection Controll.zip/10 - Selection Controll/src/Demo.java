import java.util.*;;

public class Demo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		// String s = sc.next();
		int a = sc.nextInt();
		/*
		 * syntax for if if(condition){ }
		 */
		boolean b = true;
		if (a>89) {
		System.out.println("hello");
		System.out.println("value of a "+a);
		}
		else{
			System.out.println("condition fail");
		}
	}

}
