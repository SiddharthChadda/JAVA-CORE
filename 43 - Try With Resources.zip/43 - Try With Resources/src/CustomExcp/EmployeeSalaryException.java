package CustomExcp;

public class EmployeeSalaryException extends Exception {

	public EmployeeSalaryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeSalaryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
