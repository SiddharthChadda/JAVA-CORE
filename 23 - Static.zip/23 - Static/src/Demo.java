
public class Demo {
	public static void main(String[] args) {
		System.out.println("inside main before");
		new Test(5);
		System.out.println("inside main after");
	
	}

}
