import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter value for a");
		String a=sc.nextLine();
		System.out.println(a);

	}

}
