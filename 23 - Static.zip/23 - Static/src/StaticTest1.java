
public class StaticTest1 {

	public static void main(String[] args) {
		System.out.println(StaticTest.Name);
		StaticTest.rulesDeclation();
		
	}

}
