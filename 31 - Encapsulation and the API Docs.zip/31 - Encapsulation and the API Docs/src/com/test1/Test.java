package com.test1;
class Test {
public static void main(String[] args) {
         BeanTest bn=new BeanTest();
              
             
	}
}
