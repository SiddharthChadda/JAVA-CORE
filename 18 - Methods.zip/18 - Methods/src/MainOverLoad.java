
public class MainOverLoad {

	synchronized strictfp final static public void main(String... ramu) {
		main(577);
	}

	public static void main(int a) {
		System.out.println(a);

	}

	public static void main(String a) {
		System.out.println(a);

	}
}
