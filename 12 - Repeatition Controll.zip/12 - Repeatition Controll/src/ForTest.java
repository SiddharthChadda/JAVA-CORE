
public class ForTest {

	public static void main(String[] args) {
	
		/*for(initialization;condition;increment/decrement){
			}
		*/
		
/*
		for (int i=0; i < 10;i++ ) {
			System.out.println("for loop "+i);
	
			}
	int i=0;
		for (; i < 10; ) {
			System.out.println("hello "+i);
			i++;
		}*/
		
		for (int i = 0; i < 10; ) {
			System.out.println(i);
			if (i==5) {
			break;
			}
			i++;
		}
		
/*		int i = 1;
		for (System.out.println("hello"); i < 10; System.out.println("java")) {
			System.out.println("world");
			i++;
		}*/
	}
}
