import java.util.Scanner;

public class ScannerUse {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a value");
float a=sc.nextFloat();
		System.out.println("The value of a is :"+a);
		

	}

}
