

public class MarkerTest {
          
	public static void main(String[] args) {
		
		
		
	     Marker nm=new NewMarker();
		 nm.pointerSize();
		System.out.println(nm.price);
		nm.lukfeel();
		///nm.addGrip();
		
		    NewMarker    mm= (NewMarker) nm;
		    mm.
		
    /*NewMarker n = new NewMarker(23, "luxor", "blue", 67);
		n.addGrip();
		n.lukfeel();
		n.pointerSize();
		n.writingQuality();
		n.markerDetails();*/
	}

}
