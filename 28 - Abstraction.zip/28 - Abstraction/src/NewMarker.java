

public class NewMarker extends Marker {

	@Override
	void writingQuality() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void lukfeel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void pointerSize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void pointerSize(float size) {
		// TODO Auto-generated method stub
		
	}
	
}
