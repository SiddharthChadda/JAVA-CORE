package multileInh;

public interface I1 {
	int ABC=10;
	void disp();
	
}
