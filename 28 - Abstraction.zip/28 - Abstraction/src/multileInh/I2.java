package multileInh;

public interface I2 {
	void disp();
}
