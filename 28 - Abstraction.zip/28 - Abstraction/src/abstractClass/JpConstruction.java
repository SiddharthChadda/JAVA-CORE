package abstractClass;

public  class JpConstruction extends TwoBhkHouse {

	@Override
	void kitchinType() {
		// TODO Auto-generated method stub
		System.out.println("modular");
	}

	@Override
	void roomDimension() {
		
		System.out.println("20 X 30");
	}

	@Override
	void hallDimension() {
		System.out.println("30 X 40");
		
	}

	@Override
	void flatDescription() {
	
		
	}

	void welcomeMsg(){
		System.out.println("welcome to all");
	}


}
