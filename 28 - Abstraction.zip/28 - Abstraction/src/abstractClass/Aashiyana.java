package abstractClass;

public class Aashiyana extends TwoBhkHouse {
    	@Override
	void kitchinType() {
		System.out.println("normal");

	}

	@Override
	void roomDimension() {
		// TODO Auto-generated method stub
		System.out.println("25 X 50");
	}

	@Override
	void hallDimension() {
		// TODO Auto-generated method stub
		System.out.println("40 X 60");
	}

	@Override
	void flatDescription() {
		System.out.println("velly infront of tha flat");

	}
}
