package InterfaceTest;

public  class Inf1Impl  implements Inf1,Inf2{

	@Override																																					    
	public void disp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void msg() {
		// TODO Auto-generated method stub
		
	}
	void hg(){
		
	}
public static void main(String[] args) {
	Inf1 i=new Inf1Impl();
	i.disp();
	i.hg
}

@Override
public void disp1() {
	// TODO Auto-generated method stub
	
}
}
