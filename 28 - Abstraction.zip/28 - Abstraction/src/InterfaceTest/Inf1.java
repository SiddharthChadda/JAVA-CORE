package InterfaceTest;

public abstract interface Inf1 {
	// class level constant
	int id=89;// public static final int id=90;
	
	// abstract method
void disp();// public abstract void disp();
public abstract void msg();
}
