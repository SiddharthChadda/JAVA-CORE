package InterfaceTest;

public abstract interface Inf2 {
	// class level constant
	int id1=89;// public static final int id=90;
	
	// abstract method
void disp1();// public abstract void disp();
public abstract void msg();
}
