package InterfaceTest;

public interface Inf3 extends Inf1,Inf2{

}
