
public class Test {

	public static void main(String[] args) {
          int i=4;
           System.out.println(i^5);  
           
	}

}
