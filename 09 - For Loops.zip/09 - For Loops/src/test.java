public class test {

	

	/**
	 * @param args
	 */

	public static void main(String[] args) {
	
	
     if (true) 
		System.out.println("hello");
		         
	 else ;
		 System.out.println("world");  
	
		
		
		
	}

}
