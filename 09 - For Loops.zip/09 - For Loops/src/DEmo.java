
public class DEmo{

	public static void main(String[] args) {
		byte b=14;
		b=(byte) (b+1);
		b++;
	    int a[][]=new int[3][5];
		
		
	}

}
