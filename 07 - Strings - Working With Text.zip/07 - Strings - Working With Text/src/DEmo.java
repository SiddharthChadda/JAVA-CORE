
public class DEmo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	String s="hello";
	String st=s+"ank";
	s.concat("java");
	String s1="hello";
	String s2="help";
	String str=new String("hello");
	String str1=new String("hello");
	System.out.println(str==str1);
	String a=str.concat("aptech");
	System.out.println(str);

	}

}
