
public class TestMulti {

	public static void main(String[] args) {
		int a[][][]={{{2,6},{4,6,8}},{{1},{6}},{{5,7,9},{3,5,8}}};
		System.out.println(a[2][1][1]);
	}
}
