package test;

public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	Test t=new Test();
	t.display();

	}

}
