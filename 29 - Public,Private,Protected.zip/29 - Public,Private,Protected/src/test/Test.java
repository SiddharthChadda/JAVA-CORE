package test;

public class Test {
	protected int i=90;
	protected void display(){
		System.out.println("hello");
	}

}
