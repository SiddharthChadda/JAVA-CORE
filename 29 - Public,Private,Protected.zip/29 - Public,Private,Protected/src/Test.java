


public class Test {
	//private protected int i=7;
	/**
	 * @param args
	 */
	protected int a = 2;
	protected void funct ()
	{
		System.out.println("a");
	}

	public static void main(String[] args) {
		Test t=new Test();
		t.funct();
		
		
		System.out.println("");
		//System.loadLibrary("MethodLibraary");

	}

}
