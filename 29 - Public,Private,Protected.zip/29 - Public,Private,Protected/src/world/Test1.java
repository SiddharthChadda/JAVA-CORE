package world;

import test.Test;

public class Test1 extends Test{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	Test1 t=new Test1();
	t.display();

	}

}
